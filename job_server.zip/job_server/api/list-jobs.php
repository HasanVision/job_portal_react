<?php
require_once('../config/database.php');

// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Fetch all jobs from the database
$result = $conn->query("SELECT id, title, requirements, salary, location, created_at FROM jobs ORDER BY created_at DESC");

// Check if any jobs exist
if ($result->num_rows > 0) {
    $jobs = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($jobs);
} else {
    echo json_encode(['message' => 'No jobs found']);
}

// Close the connection
$conn->close();
?>